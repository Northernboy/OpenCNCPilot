﻿namespace OpenCNCPilot.GCode.GCodeCommands
{
	public interface Command
	{
		
	}
}
